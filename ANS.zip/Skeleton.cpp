if (骨骼) {
float boxWidth = 7.f - Distance * 0.03;
draw->AddCircle({HeadPosSC.x, HeadPosSC.y}, boxWidth, PlayerBoxClrCf, 0, 0.3f); }
if (骨骼) {
float boxHeight = fabsf(RootPosSC.y - HeadPosSC.y);
float boxWidth = boxHeight * 0.3f;
draw->AddLine({upper_rPoSC.x, upper_rPoSC.y}, neck_01PoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({upper_lPoSC.x, upper_lPoSC.y}, neck_01PoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({upper_rPoSC.x, upper_rPoSC.y}, lowerarm_rPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({lowerarm_rPoSC.x, lowerarm_rPoSC.y}, hand_rPoSC, PlayerBoxClrCf , 0.3f);
draw->AddLine({upper_lPoSC.x, upper_lPoSC.y}, lowerarm_lSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({lowerarm_lSC.x, lowerarm_lSC.y}, hand_lPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({thigh_rPoSC.x, thigh_rPoSC.y}, thigh_lPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({thigh_lPoSC.x, thigh_lPoSC.y}, calf_lPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({calf_lPoSC.x, calf_lPoSC.y}, foot_lPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({thigh_rPoSC.x, thigh_rPoSC.y}, calf_rPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({calf_rPoSC.x, calf_rPoSC.y}, foot_rPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({neck_01PoSC.x, neck_01PoSC.y}, pelvisPoSC, PlayerBoxClrCf, 0.3f);
draw->AddLine({neck_01PoSC.x, neck_01PoSC.y}, HeadPosSC, PlayerBoxClrCf, 0.3f);
if (Distance < 40.0f) {
draw->AddCircleFilled(ImVec2(thigh_rPoSC.x, thigh_rPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(calf_rPoSC.x, calf_rPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(thigh_lPoSC.x, thigh_lPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(calf_lPoSC.x, calf_lPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(thigh_rPoSC.x, thigh_rPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(upper_lPoSC.x, upper_lPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(lowerarm_lSC.x, lowerarm_lSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(lowerarm_rPoSC.x, lowerarm_rPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(upper_rPoSC.x, upper_rPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(upper_lPoSC.x, upper_lPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(pelvisPoSC.x, pelvisPoSC.y), boxWidth / 20, 骨骼小白点);
draw->AddCircleFilled(ImVec2(neck_01PoSC.x, neck_01PoSC.y), boxWidth / 20, 骨骼小白点);
}}